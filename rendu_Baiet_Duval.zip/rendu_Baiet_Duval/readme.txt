Lien vers le site : 
https://etudiant.u-pem.fr/~abaiet/pokedex/index.php

Pas besoin de login ou de mot de passe spécifique : 
vous pouvez créer votre propre compte.
