<?php
  define("COOKIE_LIFE", 3600*24*30); // Durée de vie : 1 mois.
?>