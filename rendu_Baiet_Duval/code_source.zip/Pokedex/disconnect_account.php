<?php
  setcookie("user", NULL, -1);
  header("location:index.php");
?>