Lien vers le site : 
https://etudiant.u-pem.fr/~abaiet/pokedex/index.php

nom du compte : test
code du compte : test

Vous pouvez aussi créer votre propre compte facilement 
