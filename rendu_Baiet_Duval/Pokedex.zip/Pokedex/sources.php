<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <title>Pokédex</title>
  <link rel="stylesheet" type="text/css" href="style.css">
</head>

<body>
  <h1>Pokedex BDD</h1>
  <h2>Sources</h2>
  <ol>
    <li>Image de présentation :<a href="https://apkpure.com/fr/pokemon-wallpaper-pokemon-4k-pokemon-gif/com.hdpokemon.wallpaper">https://apkpure.com/fr/pokemon-wallpaper-pokemon-4k-pokemon-gif/com.hdpokemon.wallpaper</a></li>
  </ol>

</body>
</html>